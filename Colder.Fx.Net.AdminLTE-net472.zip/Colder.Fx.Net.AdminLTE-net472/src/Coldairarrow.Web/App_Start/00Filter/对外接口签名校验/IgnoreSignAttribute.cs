﻿using System;

namespace Coldairarrow.Web
{
    /// <summary>
    /// 忽略接口签名校验
    /// </summary>
    public class IgnoreSignAttribute : Attribute
    {
        
    }
}