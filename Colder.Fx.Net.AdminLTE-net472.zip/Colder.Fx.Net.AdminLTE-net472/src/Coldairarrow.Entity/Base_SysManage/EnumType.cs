﻿namespace Coldairarrow.Entity.Base_SysManage
{
    /// <summary>
    /// 枚举类型
    /// </summary>
    public class EnumType
    {
        /// <summary>
        /// 系统角色类型
        /// </summary>
        public enum RoleType
        {
            超级管理员 = 1,
            部门管理员 = 2
        }
    }
}
