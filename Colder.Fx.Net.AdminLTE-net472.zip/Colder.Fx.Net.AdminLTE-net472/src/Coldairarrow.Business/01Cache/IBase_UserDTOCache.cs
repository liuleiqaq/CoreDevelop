﻿using Coldairarrow.Business.Base_SysManage;

namespace Coldairarrow.Business.Cache
{
    public interface IBase_UserDTOCache : IBaseCache<Base_UserDTO>
    {

    }
}