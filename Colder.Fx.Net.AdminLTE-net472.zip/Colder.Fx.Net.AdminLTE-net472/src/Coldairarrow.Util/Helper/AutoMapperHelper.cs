﻿using AutoMapper;

namespace Coldairarrow.Util
{
    public static class AutoMapperHelper
    {
        public static IMapper Mapper { get; set; }
    }
}
