﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Coldairarrow.UnitTests
{
    [TestClass]
    public class UnitTestDemo
    {
        [TestMethod]
        public void TestMethodDemo()
        {
            Assert.AreEqual("1", "1");
        }
    }
}
