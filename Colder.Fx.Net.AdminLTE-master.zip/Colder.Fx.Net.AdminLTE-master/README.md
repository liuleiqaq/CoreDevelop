# Colder.Fx.Net.AdminLTE
Web后台快速开发框架,.NET472+AdminLTE版本

使用方式：https://github.com/Coldairarrow/Colder.Fx.Net.AdminLTE/wiki

国内镜像：https://gitee.com/Coldairarrow/Colder.Fx.Net.AdminLTE

博客介绍：https://www.cnblogs.com/coldairarrow/articles/10486184.html
