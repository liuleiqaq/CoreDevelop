namespace Coldairarrow.Business.Base_SysManage
{
    public interface IBase_SysLogBusiness : ILogSearcher
    {

    }
}