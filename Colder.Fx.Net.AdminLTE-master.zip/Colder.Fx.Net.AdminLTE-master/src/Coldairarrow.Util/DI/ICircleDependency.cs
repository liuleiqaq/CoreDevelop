﻿namespace Coldairarrow.Util
{
    /// <summary>
    /// 循环依赖注入标记
    /// </summary>
    public interface ICircleDependency
    {

    }
}
