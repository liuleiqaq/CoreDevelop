﻿namespace Coldairarrow.Util
{
    /// <summary>
    /// 注入标记
    /// </summary>
    public interface IDependency
    {

    }
}
