﻿using System;

namespace Coldairarrow.Web
{
    /// <summary>
    /// 忽略登录校验
    /// </summary>
    public class IgnoreLoginAttribute : Attribute
    {
        
    }
}