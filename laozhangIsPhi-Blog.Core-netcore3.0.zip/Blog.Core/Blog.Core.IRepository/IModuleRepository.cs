using Blog.Core.IRepository.Base;
using Blog.Core.Model.Models;

namespace Blog.Core.IRepository
{	
	/// <summary>
	/// IModuleRepository
	/// </summary>	
	public interface IModuleRepository : IBaseRepository<Module>//类名
    {

       
    }
}


	